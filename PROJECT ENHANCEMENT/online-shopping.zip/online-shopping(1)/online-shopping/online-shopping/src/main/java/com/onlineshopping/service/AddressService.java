package com.onlineshopping.service;

import com.onlineshopping.model.Address;

public interface AddressService {

    boolean saveAddress(Address address);

    Address findAddressByBilling(boolean billing);

}

package com.onlineshopping.service;

import com.onlineshopping.model.User;

public interface UserService {

    boolean saveUser(User user);

    User findUserByEmail(String email);

}

package com.isolutions4u.onlineshopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OnlineShoppingApplicationTests {

    @Test
    public void contextLoads() {
    }

}
